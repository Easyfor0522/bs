## step1 数据集预处理

加载 UCF101 数据集

参考：[Emily0219/video-dataset-preprocess: code about preprocessing and dataloaders for video dataset including UCF101 and HMDB51 based on PyTorch (github.com)](https://github.com/Emily0219/video-dataset-preprocess)

参考文献：

```
@inproceedings{hara3dcnns,
  author={Kensho Hara and Hirokatsu Kataoka and Yutaka Satoh},
  title={Can Spatiotemporal 3D CNNs Retrace the History of 2D CNNs and ImageNet?},
  booktitle={Proceedings of the IEEE Conference on Computer Vision and Pattern Recognition (CVPR)},
  pages={6546--6555},
  year={2018},
}
```



#### 1.1 run video2jpg_ucf101.py （注意修改路径）

​	切割avi视频转化为jpg

#### 1.2 run n_frames_ucf101.py （注意修改路径）

​	记录每个视频的帧数

#### 1.3 After pre-processing, the image output dir's structure is as follows:

```
  UCF101_n_frames
  ├── ApplyEyeMakeup
  │   ├── v_ApplyEyeMakeup_g01_c01
  │   │   ├── image_00001.jpg
  │   │   ├── ...
  │   │   └── n_frames
  │   └── ...
  ├── ApplyLipstick
  │   ├── v_ApplyLipstick_g01_c01
  │   │   ├── image_00001.jpg
  │   │   ├── ...
  │   │   └── n_frames
  │   └── ...
  ├── Archery
  │   ├── v_Archery_g01_c01
  │   │   ├── image_00001.jpg
  │   │   ├── ...
  │   │   └── n_frames
  │   └── ...
```



## step2 Dataloader

dataset 类已经写好，dataloader/ucf_dataset

设置 data_type类型

​	video：输出视频

​	motion：输出运行序列（使用mediapipe 处理后的，经测试，mediapipe不支持多人，只能输出最靠前人的pose）

**run train.py**，如果能输出下列代码，说明OK

![image-20240319134044508](img/img.png)



## step3 定义网络

待完成，网络可以先不写，先写 训练

先不考虑网络的性能和复杂度，

只要求: 输入的shape 为 [batch_size, rgb, frames, w, h],输出的shape 为 [batch_size, 1]，输出的是数字标签，表示某个类别





## step4 训练 

训练过程的参考代码已给出，请完成 设计网络并完成训练



## step5 可视化训练过程

可视化 loss 变化 和 acc 变化

做几个mediapipe 的demo

